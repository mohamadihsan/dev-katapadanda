/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'pt', {
	embeddingInProgress: 'Trying to embed pasted URL...', // MISSING
	embeddingFailed: 'Não foi possível embeber diretamente este URL.'
} );
